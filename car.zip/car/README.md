Classic Car Online Selling 

# this system will help someone who need to buy a car. Its easy to make a car order and easy for payment.


1. Create an Account 
2. Login using username and password 
3. On Home page select Car and click on Order 
4. Wait for admin to Accept your request 
5. If Admin accept your request you will be able to pay your Order using the methods shown 
6. After paying you wait for admin to confirm your payment 
7. Then you wait for your delivery.
