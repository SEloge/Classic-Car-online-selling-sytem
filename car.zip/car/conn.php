<?php
session_start();
$mysqli=new mysqli("localhost","root","","car");
$feedback="";
$feed="";
?>